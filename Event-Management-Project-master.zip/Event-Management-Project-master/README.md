# Event-Management-Project
Source Code for the event management project at eventmanagement.pythonanywhere.com
