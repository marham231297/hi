# EasyFile
<h2><strong>EasyFile | Advanced File Management System</strong></h2>

The purpose of this program is to help you manage files more easily. Features of this program are...

<li>Move Multiple Files At Once</li>
<li>Create Pass-Protected ZIP Files</li>
<li>SFTP Client for Remote File Management</li>
<li>Download Images</li>
<li>Download Source Code of Any Website</li>

<h3>----- Usage ----- </h3>
<ul>
  <li> ---> chmod +x setup.sh </li>
  <li> ---> ./setup.sh </li>
  <li> ---> python3 main.py </li> 
</ul>


