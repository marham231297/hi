#!/bin/bash

echo "Installing Modules..."
pip3 install -r requirements.txt
echo "Starting Script..."
python3 main.py

